﻿namespace BookApp.DTO
{
    public class AuthDto
    {
        public string? Token { get; set; }
        public string? Username { get; set; }
    }
}
